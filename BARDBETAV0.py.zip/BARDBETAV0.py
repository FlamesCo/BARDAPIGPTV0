import os
import tkinter as tk
import webbrowser
import openai

def get_api_key():
    api_key = os.getenv("OPENAI_API_KEY")
    if api_key is None:
        print("Please enter your OpenAI API key:")
        api_key = input().strip()
    return api_key

openai.api_key = get_api_key()

class DorkingApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("BARD-")
        self.geometry("300x200")
        self.create_widgets()

    def create_widgets(self):
        self.query_label = tk.Label(self, text="Enter your dork query:")
        self.query_label.pack(pady=10)

        self.query_entry = tk.Entry(self)
        self.query_entry.pack(pady=10)

        self.search_button = tk.Button(self, text="Search", command=self.perform_search)
        self.search_button.pack(pady=10)

    def perform_search(self):
        query = self.query_entry.get()
        prompt = f"Google dork search results for: {query}\n\n"

        response = openai.Completion.create(
            engine="text-davinci-002",
            prompt=prompt,
            max_tokens=100,
            n=1,
            stop=None,
            temperature=0.8,
        )

        results = response.choices[0].text.strip().split("\n")

        for result in results:
            webbrowser.open(result)

if __name__ == "__main__":
    app = DorkingApp()
    app.mainloop()
